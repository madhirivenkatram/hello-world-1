from __future__ import annotations

import argparse
import base64
import binascii
import concurrent.futures
import csv
import fnmatch
import getpass
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator, List, Optional, Sequence, Tuple


TEXT_EXTENSIONS = {
    ".py", ".ps1", ".psm1", ".psd1", ".js", ".ts", ".jsx", ".tsx", ".java", ".cs",
    ".go", ".rb", ".php", ".pl", ".sh", ".bash", ".zsh", ".ksh", ".sql", ".txt",
    ".json", ".yaml", ".yml", ".ini", ".cfg", ".conf", ".config", ".properties",
    ".env", ".xml", ".toml", ".tf", ".tfvars", ".gradle", ".md", ".rst", ".bat",
    ".cmd", ".aspx", ".jsp", ".swift", ".kt", ".kts", ".scala", ".c", ".cpp", ".h",
    ".hpp", ".m", ".mm", ".dart", ".vue", ".svelte", ".dockerfile",
}

SKIP_DIRS = {
    ".git", ".svn", ".hg", "node_modules", "dist", "build", "target", "bin", "obj",
    ".next", ".nuxt", ".venv", "venv", "env", "__pycache__", ".mypy_cache",
    ".pytest_cache", ".tox", ".idea", ".vscode", "coverage", ".terraform",
}

SKIP_FILE_NAMES = {
    ".ds_store", "thumbs.db", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "poetry.lock", "cargo.lock",
}

ALWAYS_SCAN_HIDDEN_FILE_NAMES = {
    ".env",
    ".env.local",
    ".env.development",
    ".env.production",
    ".env.staging",
    ".env.test",
    ".npmrc",
    ".pypirc",
    ".netrc",
    ".dockercfg",
    ".htpasswd",
}

LOW_CONFIDENCE_VALUES = {
    "changeme", "changeit", "password", "passwd", "secret", "example", "sample",
    "dummy", "test", "null", "none", "undefined", "default", "your_password_here",
}

VARIABLE_REFERENCE_PATTERNS: Sequence[re.Pattern[str]] = (
    re.compile(r"\{\{\s*[^{}]+\s*\}\}", re.IGNORECASE),
    re.compile(r"\$\{\{\s*[^{}]+\s*\}\}", re.IGNORECASE),
    re.compile(r"\$\{\s*[^{}]+\s*\}", re.IGNORECASE),
    re.compile(r"%[^%]+%", re.IGNORECASE),
    re.compile(r"\$env:[A-Za-z_][A-Za-z0-9_]*", re.IGNORECASE),
    re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*", re.IGNORECASE),
    re.compile(r"\$\([^)]+\)", re.IGNORECASE),
    re.compile(r"var\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"local\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"module\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"data\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"\.values\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"values\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"secrets\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"vars\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"parameters\.[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile(r"os\.getenv\([^)]*\)", re.IGNORECASE),
    re.compile(r"os\.environ\[[^\]]+\]", re.IGNORECASE),
    re.compile(r"system\.getenv\([^)]*\)", re.IGNORECASE),
    re.compile(r"environment\.getenvironmentvariable\([^)]*\)", re.IGNORECASE),
    re.compile(r"config(?:uration)?\[[^\]]+\]", re.IGNORECASE),
    re.compile(r"process\.env\.[A-Za-z_][A-Za-z0-9_]*", re.IGNORECASE),
    re.compile(r"process\.env\[[^\]]+\]", re.IGNORECASE),
    re.compile(r"env\([^)]+\)", re.IGNORECASE),
)

GENERIC_STRING_LITERAL_RE = re.compile(
    r'"(?P<double>(?:[^"\\]|\\.){12,})"|'
    r"'(?P<single>(?:[^'\\]|\\.){12,})'|"
    r"`(?P<backtick>(?:[^`\\]|\\.){12,})`"
)

UUID_PATTERN = re.compile(
    r"^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$",
    re.IGNORECASE,
)

DEFAULT_SECRET_KEYWORDS = (
    "password", "passwd", "pass", "passphrase", "pwd", "secret", "token",
    "apikey", "api_key", "apitoken", "api_token", "access_key", "access_token",
    "refresh_token", "id_token", "session_token", "bearer_token", "secret_key",
    "private_key", "privatekey", "ssh_private_key", "pem_key", "client_secret",
    "consumer_key", "consumer_secret",
    "app_key", "app_secret", "auth", "credential", "credentials",
    "db_password", "database_password", "admin_password", "root_password",
    "user_password", "ansible_password", "domain_admin_password", "vcenter_password",
    "connectionstring", "connection_string", "conn_string",
    "jdbc_url", "database_url", "mongo_url", "redis_url", "webhook",
    "webhook_url", "sas", "sas_token", "sig", "signature", "license_key",
    "encryption_key", "keystore_password", "pat",
    "personal_access_token", "github_token", "gitlab_token", "bitbucket_token",
)


@dataclass(frozen=True)
class Finding:
    file_path: str
    line_number: int
    severity: str
    finding_type: str
    sensitive_content: str
    detection_reason: str
    owner: str
    repository_name: str


@dataclass(frozen=True)
class PatternRule:
    name: str
    severity: str
    pattern: re.Pattern[str]


@dataclass(frozen=True)
class AllowlistRule:
    path_pattern: Optional[str] = None
    finding_type: Optional[str] = None
    severity: Optional[str] = None
    line_number: Optional[int] = None
    content_regex: Optional[re.Pattern[str]] = None
    owner: Optional[str] = None
    repository_name: Optional[str] = None


@dataclass(frozen=True)
class ZipSafetyLimits:
    max_members: int
    max_total_uncompressed_bytes: int
    max_member_size_bytes: int
    max_depth: int


HIGH_CONFIDENCE_RULES: Sequence[PatternRule] = (
    PatternRule("AWS Access Key", "High", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    PatternRule("AWS STS Key", "High", re.compile(r"\bASIA[0-9A-Z]{16}\b")),
    PatternRule("GitHub Token", "High", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,255}\b")),
    PatternRule("GitHub Fine-Grained Token", "High", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,255}\b")),
    PatternRule("Slack Token", "High", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,200}\b")),
    PatternRule("Slack Webhook", "High", re.compile(r"https://hooks\.slack\.com/services/[A-Za-z0-9/_-]+")),
    PatternRule("Stripe Secret Key", "High", re.compile(r"\bsk_(live|test)_[A-Za-z0-9]{16,128}\b")),
    PatternRule("Google API Key", "High", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b")),
    PatternRule("SendGrid API Key", "High", re.compile(r"\bSG\.[A-Za-z0-9_\-]{16,128}\.[A-Za-z0-9_\-]{16,128}\b")),
    PatternRule("Twilio SID", "Medium", re.compile(r"\bAC[a-f0-9]{32}\b", re.IGNORECASE)),
    PatternRule("JWT", "High", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9._-]{8,}\.[A-Za-z0-9._-]{8,}\b")),
    PatternRule("Azure Storage Connection String", "High", re.compile(r"DefaultEndpointsProtocol=.*?;AccountName=.*?;AccountKey=.*?(;|$)", re.IGNORECASE)),
    PatternRule("Database URL With Credentials", "High", re.compile(r"\b(?:postgres(?:ql)?|mysql|mssql|mongodb(?:\+srv)?|redis|amqp)://[^/\s:@]+:[^@\s]+@[^/\s]+", re.IGNORECASE)),
    PatternRule("Private Key Header", "High", re.compile(r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----")),
    PatternRule("Certificate Header", "Medium", re.compile(r"-----BEGIN CERTIFICATE-----")),
    PatternRule("Azure SAS Token", "High", re.compile(r"\bsv=[^&\s]+&ss=[^&\s]+&srt=[^&\s]+&sp=[^&\s]+&se=[^&\s]+&st=[^&\s]+&spr=[^&\s]+&sig=[^&\s]+", re.IGNORECASE)),
    PatternRule("Generic Auth Bearer", "Medium", re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]+=*\b", re.IGNORECASE)),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Scan folders for hardcoded sensitive information and export a CSV report."
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=None,
        help="Folder, file, zip archive, or Git repository URL to scan. If omitted, the script prompts for a source.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="CSV output path. Default: <repo-or-folder-name>.csv",
    )
    parser.add_argument(
        "--include-hidden",
        action="store_true",
        help="Include hidden files and folders.",
    )
    parser.add_argument(
        "--max-file-size-kb",
        type=int,
        default=1024,
        help="Skip files larger than this size in KB. Default: 1024",
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Fail instead of prompting when target is not supplied.",
    )
    parser.add_argument(
        "--targets-csv",
        help="CSV file containing multiple scan targets. Expected columns: target or github_url/local_path. Optional: owner, repository_name.",
    )
    parser.add_argument(
        "--format",
        choices=("csv", "json", "sarif"),
        default="csv",
        help="Output format. Default: csv",
    )
    parser.add_argument(
        "--fail-on",
        choices=("low", "medium", "high"),
        default=None,
        help="Exit with code 2 if findings meet or exceed this severity threshold.",
    )
    parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        help="Glob pattern to exclude paths from scanning. Can be repeated.",
    )
    parser.add_argument(
        "--allowlist-file",
        default=None,
        help="Path to a JSON allowlist file for suppressing known-safe findings.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="Number of worker threads for scanning directories. Default: auto.",
    )
    parser.add_argument(
        "--max-zip-members",
        type=int,
        default=2000,
        help="Maximum number of entries allowed in a zip archive. Default: 2000",
    )
    parser.add_argument(
        "--max-zip-uncompressed-mb",
        type=int,
        default=100,
        help="Maximum total uncompressed size allowed per zip archive in MB. Default: 100",
    )
    parser.add_argument(
        "--max-zip-member-size-mb",
        type=int,
        default=20,
        help="Maximum uncompressed size allowed for a single zip member in MB. Default: 20",
    )
    parser.add_argument(
        "--max-zip-depth",
        type=int,
        default=2,
        help="Maximum nested zip depth to scan. Default: 2",
    )
    return parser.parse_args()


def prompt_for_target() -> str:
    print("Choose scan target type:")
    print("1. Git repository URL")
    print("2. Local folder, file, or zip path")
    print("3. CSV file with multiple targets")

    while True:
        choice = input("Enter 1, 2, or 3: ").strip()
        if choice == "1":
            value = input("Enter Git repository URL: ").strip()
            if value:
                return value
            print("Git repository URL cannot be empty.")
        elif choice == "2":
            value = input("Enter local folder, file, or zip path: ").strip().strip('"')
            if value:
                return value
            print("Local path cannot be empty.")
        elif choice == "3":
            value = input("Enter CSV file path: ").strip().strip('"')
            if value:
                return value
            print("CSV file path cannot be empty.")
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")


def is_remote_git_url(value: str) -> bool:
    lowered = value.lower()
    return lowered.startswith((
        "https://",
        "http://",
        "ssh://",
        "git@",
    )) and (
        lowered.endswith(".git")
        or "github.com/" in lowered
        or "bitbucket.org/" in lowered
        or "gitlab.com/" in lowered
        or "dev.azure.com/" in lowered
        or "visualstudio.com/" in lowered
        or "/_git/" in lowered
    )


def detect_provider(repo_url: str) -> str:
    lowered = repo_url.lower()
    if "github.com" in lowered:
        return "github"
    if "bitbucket.org" in lowered:
        return "bitbucket"
    if "gitlab" in lowered:
        return "gitlab"
    if "dev.azure.com" in lowered or "visualstudio.com" in lowered or "/_git/" in lowered:
        return "azure_devops"
    return "generic_git"


def derive_repo_name_from_url(repo_url: str) -> str:
    cleaned = repo_url.rstrip("/").split("/")[-1]
    if cleaned.endswith(".git"):
        cleaned = cleaned[:-4]
    return cleaned or "sensitive_report"


def sanitize_file_stem(name: str) -> str:
    sanitized = re.sub(r'[<>:"/\\|?*]+', "_", name.strip())
    return sanitized or "sensitive_report"


def mask_secret(value: str) -> str:
    value = value.strip()
    if not value:
        return value
    if len(value) == 1:
        return "*"
    if len(value) == 2:
        return f"{value[0]}*"
    return f"{value[0]}{'*' * (len(value) - 2)}{value[-1]}"


def mask_sensitive_content(content: str) -> str:
    content = content.strip()
    if "=" in content:
        key, value = content.split("=", 1)
        return f"{key}={mask_secret(value)}"
    return mask_secret(content)


def keyword_to_regex_fragment(keyword: str) -> str:
    escaped = re.escape(keyword.strip())
    escaped = escaped.replace(r"\_", "[_-]?")
    return escaped


def build_assignment_regex(secret_keywords: Sequence[str]) -> re.Pattern[str]:
    keyword_fragments = sorted(
        {keyword_to_regex_fragment(keyword) for keyword in secret_keywords if keyword.strip()},
        key=len,
        reverse=True,
    )
    if not keyword_fragments:
        keyword_fragments = [r"password", r"token", r"secret"]

    keyword_pattern = "|".join(keyword_fragments)
    pattern = rf"""
    \b
    (?P<key>[A-Za-z0-9_.-]*(?:{keyword_pattern})[A-Za-z0-9_.-]*)
    \b
    \s*
    (?:
        =|:|:=|=>|->|
        \bset\b\s+\w+\s*=|
        \bexport\b\s+\w+\s*=
    )
    \s*
    (?P<quote>["']?)
    (?P<value>[^\s"',;}}{{]{{4,}}|.*?)
    (?P=quote)
    """
    return re.compile(pattern, re.IGNORECASE | re.VERBOSE)


def normalize_keyword(keyword: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", keyword.lower())


def find_git_executable() -> Optional[str]:
    git_path = shutil.which("git")
    if git_path:
        return git_path

    candidates = [
        r"C:\Program Files\Git\cmd\git.exe",
        r"C:\Program Files\Git\bin\git.exe",
        r"C:\Program Files (x86)\Git\cmd\git.exe",
        r"C:\Program Files (x86)\Git\bin\git.exe",
        str(Path.home() / "AppData" / "Local" / "Programs" / "Git" / "cmd" / "git.exe"),
        str(Path.home() / "AppData" / "Local" / "Programs" / "Git" / "bin" / "git.exe"),
    ]

    for candidate in candidates:
        if Path(candidate).exists():
            return candidate

    return None


def build_git_auth_env(token: str, provider: str) -> dict[str, str]:
    username_by_provider = {
        "github": "x-access-token",
        "gitlab": "oauth2",
        "bitbucket": "x-token-auth",
        "azure_devops": "",
        "generic_git": "",
    }
    username = username_by_provider.get(provider, "")
    credentials = f"{username}:{token}".encode("utf-8")
    header_value = "AUTHORIZATION: basic " + base64.b64encode(credentials).decode("ascii")

    env = os.environ.copy()
    env.update(
        {
            "GIT_CONFIG_COUNT": "1",
            "GIT_CONFIG_KEY_0": "http.extraheader",
            "GIT_CONFIG_VALUE_0": header_value,
        }
    )
    return env


def is_authentication_error(error_text: str) -> bool:
    lowered = error_text.lower()
    return any(
        marker in lowered
        for marker in (
            "authentication failed",
            "could not read username",
            "repository not found",
            "access denied",
            "fatal: could not",
            "support for password authentication was removed",
            "terminal prompts disabled",
            "authentication required",
            "403",
            "401",
            "not authorized",
            "permission denied",
        )
    )


def prompt_for_provider_token(provider: str) -> str:
    provider_label = {
        "github": "GitHub",
        "bitbucket": "Bitbucket",
        "gitlab": "GitLab",
        "azure_devops": "Azure DevOps",
        "generic_git": "Git",
    }.get(provider, "Git")
    return getpass.getpass(f"Enter {provider_label} personal access token: ").strip()


def clone_repository_with_optional_token(repo_url: str, token: Optional[str], provider: str) -> Path:
    temp_dir = Path(tempfile.mkdtemp(prefix="sensitive_scan_"))
    clone_dir = temp_dir / "repo"
    git_executable = find_git_executable()
    if not git_executable:
        raise RuntimeError(
            "git is required to scan a GitHub URL, but git could not be found in PATH or common install locations."
        )

    env = build_git_auth_env(token, provider) if token and repo_url.startswith(("https://", "http://")) else None
    try:
        subprocess.run(
            [git_executable, "clone", "--depth", "1", repo_url, str(clone_dir)],
            check=True,
            capture_output=True,
            text=True,
            env=env,
        )
    except subprocess.CalledProcessError as exc:
        error_text = (exc.stderr or exc.stdout or str(exc)).strip()
        raise RuntimeError(f"Unable to clone repository: {error_text}") from exc
    return clone_dir


def clone_repository(repo_url: str) -> Path:
    provider = detect_provider(repo_url)
    try:
        return clone_repository_with_optional_token(repo_url, token=None, provider=provider)
    except RuntimeError as exc:
        error_text = str(exc)
        if not is_authentication_error(error_text):
            raise

        print(f"This {provider.replace('_', ' ')} repository may require authentication.")
        token = prompt_for_provider_token(provider)
        if not token:
            raise RuntimeError("Access token was not provided. Unable to clone private repository.") from exc

        try:
            return clone_repository_with_optional_token(repo_url, token=token, provider=provider)
        except RuntimeError as retry_exc:
            raise RuntimeError(
                "Unable to clone repository after token authentication. Please verify the URL and token permissions."
            ) from retry_exc


def read_targets_from_csv(csv_path: Path) -> List[dict]:
    targets: List[dict] = []
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise RuntimeError("Targets CSV is empty or missing a header row.")

        for index, row in enumerate(reader, start=2):
            normalized = {str(key).strip().lower(): (value or "").strip() for key, value in row.items() if key}
            target = normalized.get("target") or normalized.get("github_url") or normalized.get("local_path")
            if not target:
                raise RuntimeError(
                    f"Targets CSV row {index} is missing target information. Use 'target', 'github_url', or 'local_path'."
                )
            targets.append(
                {
                    "target": target,
                    "owner": normalized.get("owner", ""),
                    "repository_name": normalized.get("repository_name", ""),
                }
            )
    return targets


def extract_owner_from_repo_url(repo_url: str, provider: str) -> str:
    stripped = repo_url.rstrip("/")
    if stripped.endswith(".git"):
        stripped = stripped[:-4]

    if provider == "github":
        parts = stripped.split("/")
        return parts[-2] if len(parts) >= 2 else ""

    if provider == "bitbucket":
        parts = stripped.split("/")
        return parts[-2] if len(parts) >= 2 else ""

    if provider == "gitlab":
        parts = stripped.split("/")
        return parts[-2] if len(parts) >= 2 else ""

    if provider == "azure_devops":
        if "dev.azure.com/" in stripped.lower():
            after_host = stripped.split("dev.azure.com/", 1)[1]
            segments = after_host.split("/")
            return segments[0] if segments else ""
        if ".visualstudio.com/" in stripped.lower():
            host = stripped.split("//", 1)[-1].split("/", 1)[0]
            return host.split(".visualstudio.com", 1)[0]

    return ""

def is_hidden(path: Path) -> bool:
    return any(part.startswith(".") for part in path.parts if part not in (".", ".."))


def should_scan_hidden_file_by_default(path: Path) -> bool:
    lower_name = path.name.lower()
    return (
        lower_name in ALWAYS_SCAN_HIDDEN_FILE_NAMES
        or lower_name.startswith(".env.")
    )


def looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            chunk = handle.read(4096)
    except OSError:
        return True

    if not chunk:
        return False

    if b"\x00" in chunk:
        return True

    non_text = sum(byte < 9 or (13 < byte < 32) for byte in chunk)
    return (non_text / len(chunk)) > 0.30


def should_consider_file(path: Path, include_hidden: bool, max_file_size_kb: int) -> bool:
    if not include_hidden and is_hidden(path) and not should_scan_hidden_file_by_default(path):
        return False

    if path.name.lower() in SKIP_FILE_NAMES:
        return False

    if is_zip_archive(path):
        return True

    try:
        if path.stat().st_size > max_file_size_kb * 1024:
            return False
    except OSError:
        return False

    return True


def is_zip_archive(path: Path) -> bool:
    if path.suffix.lower() != ".zip":
        return False
    try:
        return zipfile.is_zipfile(path)
    except OSError:
        return False


def should_scan_file(path: Path, include_hidden: bool, max_file_size_kb: int) -> bool:
    if not should_consider_file(path, include_hidden, max_file_size_kb):
        return False

    suffix = path.suffix.lower()
    if suffix and suffix not in TEXT_EXTENSIONS:
        return not looks_binary(path)

    return not looks_binary(path)


def iter_files(root: Path, include_hidden: bool, max_file_size_kb: int) -> Iterator[Path]:
    for current_root, dir_names, file_names in os.walk(root):
        current = Path(current_root)
        dir_names[:] = [
            directory
            for directory in dir_names
            if directory not in SKIP_DIRS
            and (include_hidden or not directory.startswith("."))
        ]

        for file_name in file_names:
            path = current / file_name
            if should_scan_file(path, include_hidden, max_file_size_kb):
                yield path


def shannon_entropy(value: str) -> float:
    if not value:
        return 0.0

    freq = {char: value.count(char) / len(value) for char in set(value)}
    return -sum(prob * math.log2(prob) for prob in freq.values())


def redact_content(value: str, max_len: int = 160) -> str:
    value = value.strip()
    if len(value) <= max_len:
        return value
    return f"{value[:80]}...{value[-20:]}"


def unescape_string_literal(value: str) -> str:
    try:
        return bytes(value, "utf-8").decode("unicode_escape")
    except UnicodeDecodeError:
        return value


def finding_to_dict(finding: Finding) -> dict:
    return {
        "owner": finding.owner,
        "repository_name": finding.repository_name,
        "file_name_with_path": finding.file_path,
        "line_number": finding.line_number,
        "sensitive_content": finding.sensitive_content,
        "severity": finding.severity,
        "finding_type": finding.finding_type,
        "detection_reason": finding.detection_reason,
    }


def severity_rank(severity: str) -> int:
    return {
        "low": 1,
        "medium": 2,
        "high": 3,
    }.get(severity.lower(), 0)


def severity_counts(findings: Sequence[Finding]) -> dict[str, int]:
    return {
        "low": sum(1 for finding in findings if finding.severity == "Low"),
        "medium": sum(1 for finding in findings if finding.severity == "Medium"),
        "high": sum(1 for finding in findings if finding.severity == "High"),
    }


def sarif_level_for_severity(severity: str) -> str:
    return {
        "High": "error",
        "Medium": "warning",
        "Low": "note",
    }.get(severity, "warning")


def sarif_rule_id(finding_type: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", finding_type.strip()) or "SensitiveFinding"


def should_fail_scan(findings: Sequence[Finding], fail_on: Optional[str]) -> bool:
    if not fail_on:
        return False
    threshold = severity_rank(fail_on)
    return any(severity_rank(finding.severity) >= threshold for finding in findings)


def matches_any_pattern(value: str, patterns: Sequence[str]) -> bool:
    normalized = value.replace("\\", "/")
    basename = Path(normalized).name
    return any(
        fnmatch.fnmatch(normalized, pattern)
        or fnmatch.fnmatch(basename, pattern)
        for pattern in patterns
    )


def is_excluded_path(path_value: str, exclude_patterns: Sequence[str]) -> bool:
    if not exclude_patterns:
        return False
    return matches_any_pattern(path_value, exclude_patterns)


def compose_display_path(prefix: str, relative_path: str) -> str:
    clean_relative = relative_path.replace("\\", "/").strip("/")
    if not prefix:
        return clean_relative
    if not clean_relative:
        return prefix.rstrip("!")
    return f"{prefix}{clean_relative}"


def compile_allowlist_regex(value: str) -> re.Pattern[str]:
    try:
        return re.compile(value)
    except re.error as exc:
        raise RuntimeError(f"Invalid allowlist content_regex '{value}': {exc}") from exc


def parse_allowlist_rule(entry: object, index: int) -> AllowlistRule:
    if not isinstance(entry, dict):
        raise RuntimeError(f"Allowlist rule {index} must be a JSON object.")

    allowed_keys = {
        "path",
        "finding_type",
        "severity",
        "line_number",
        "content_regex",
        "owner",
        "repository_name",
    }
    unknown_keys = set(entry) - allowed_keys
    if unknown_keys:
        unknown_list = ", ".join(sorted(unknown_keys))
        raise RuntimeError(f"Allowlist rule {index} contains unsupported keys: {unknown_list}")

    line_number = entry.get("line_number")
    if line_number is not None and not isinstance(line_number, int):
        raise RuntimeError(f"Allowlist rule {index} field 'line_number' must be an integer.")

    severity = entry.get("severity")
    if severity is not None and str(severity).lower() not in {"low", "medium", "high"}:
        raise RuntimeError(f"Allowlist rule {index} field 'severity' must be Low, Medium, or High.")

    content_regex = entry.get("content_regex")
    compiled_regex = compile_allowlist_regex(content_regex) if content_regex else None

    return AllowlistRule(
        path_pattern=str(entry["path"]).strip() if entry.get("path") else None,
        finding_type=str(entry["finding_type"]).strip() if entry.get("finding_type") else None,
        severity=str(severity).strip().title() if severity else None,
        line_number=line_number,
        content_regex=compiled_regex,
        owner=str(entry["owner"]).strip() if entry.get("owner") else None,
        repository_name=str(entry["repository_name"]).strip() if entry.get("repository_name") else None,
    )


def load_allowlist_rules(path: Optional[str]) -> List[AllowlistRule]:
    if not path:
        return []

    allowlist_path = Path(path).expanduser().resolve()
    if not allowlist_path.exists():
        raise RuntimeError(f"Allowlist file does not exist: {allowlist_path}")

    try:
        payload = json.loads(allowlist_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Unable to load allowlist file: {exc}") from exc

    if isinstance(payload, dict):
        rules_payload = payload.get("rules")
    else:
        rules_payload = payload

    if not isinstance(rules_payload, list):
        raise RuntimeError("Allowlist file must contain a JSON array or an object with a 'rules' array.")

    return [parse_allowlist_rule(entry, index + 1) for index, entry in enumerate(rules_payload)]


def build_zip_safety_limits(
    max_members: int,
    max_total_uncompressed_mb: int,
    max_member_size_mb: int,
    max_depth: int,
) -> ZipSafetyLimits:
    if max_members <= 0:
        raise RuntimeError("--max-zip-members must be greater than 0.")
    if max_total_uncompressed_mb <= 0:
        raise RuntimeError("--max-zip-uncompressed-mb must be greater than 0.")
    if max_member_size_mb <= 0:
        raise RuntimeError("--max-zip-member-size-mb must be greater than 0.")
    if max_depth < 0:
        raise RuntimeError("--max-zip-depth must be 0 or greater.")

    return ZipSafetyLimits(
        max_members=max_members,
        max_total_uncompressed_bytes=max_total_uncompressed_mb * 1024 * 1024,
        max_member_size_bytes=max_member_size_mb * 1024 * 1024,
        max_depth=max_depth,
    )


def resolve_worker_count(requested_workers: int) -> int:
    if requested_workers < 0:
        raise RuntimeError("--workers must be 0 or greater.")
    if requested_workers > 0:
        return requested_workers
    cpu_count = os.cpu_count() or 4
    return min(32, cpu_count + 4)


def is_probably_placeholder(value: str) -> bool:
    normalized = value.strip().strip("\"'")
    lowered = normalized.lower()
    if lowered in LOW_CONFIDENCE_VALUES:
        return True
    if any(pattern.fullmatch(normalized) for pattern in VARIABLE_REFERENCE_PATTERNS):
        return True
    if lowered.startswith("${") or lowered.startswith("%") or lowered.startswith("<"):
        return True
    if lowered in {"true", "false"}:
        return True
    return False


def character_class_count(value: str) -> int:
    checks = (
        any(char.islower() for char in value),
        any(char.isupper() for char in value),
        any(char.isdigit() for char in value),
        any(not char.isalnum() for char in value),
    )
    return sum(1 for item in checks if item)


def classify_generic_secret_literal(value: str) -> Optional[str]:
    candidate = unescape_string_literal(value.strip())
    if len(candidate) < 20:
        return None
    if is_probably_placeholder(candidate):
        return None

    lowered = candidate.lower()
    if lowered.startswith(("http://", "https://")) and "token=" not in lowered and "sig=" not in lowered:
        return None
    if " " in candidate:
        return None
    if "@" in candidate and "." in candidate:
        return None
    if UUID_PATTERN.fullmatch(candidate):
        return None
    if re.fullmatch(r"[A-Fa-f0-9]{32,64}", candidate):
        return None
    if re.fullmatch(r"[A-Za-z0-9_.\-/\\:]+", candidate) and character_class_count(candidate) < 3:
        return None

    entropy = shannon_entropy(candidate)
    classes = character_class_count(candidate)

    if len(candidate) >= 24 and entropy >= 4.2 and classes >= 3:
        return "Medium"
    if len(candidate) >= 20 and entropy >= 3.8 and classes >= 3:
        return "Low"
    return None


def decode_if_base64(value: str) -> Optional[str]:
    candidate = value.strip().strip("\"'")
    if len(candidate) < 16 or len(candidate) % 4 != 0:
        return None
    if not re.fullmatch(r"[A-Za-z0-9+/=]+", candidate):
        return None
    try:
        decoded = base64.b64decode(candidate, validate=True)
    except (ValueError, binascii.Error):
        return None
    try:
        text = decoded.decode("utf-8")
    except UnicodeDecodeError:
        return None
    if "BEGIN PRIVATE KEY" in text or "password" in text.lower() or "token" in text.lower():
        return text
    return None


def classify_assignment_value(key: str, value: str, secret_keywords: Sequence[str]) -> Optional[str]:
    key_l = key.lower()
    normalized_key = normalize_keyword(key)
    value = value.strip().strip(",")
    if not value or is_probably_placeholder(value):
        return None

    lowered = value.lower().strip("\"'")
    if lowered.startswith(("http://", "https://")) and "sig=" not in lowered and "token=" not in lowered:
        return None

    if re.fullmatch(r"[\w.-]+", lowered) and len(lowered) < 8:
        if not any(marker in key_l for marker in ("pass", "pwd", "user", "login", "cert", "id", "key")):
            return None

    if "connection" in key_l and ";" in value and "=" in value:
        return "High"
    if any(marker in key_l for marker in ("private_key", "privatekey", "ssh_private_key", "pem_key", "client_secret", "secret_key", "consumer_secret", "app_secret", "encryption_key")):
        return "High"
    if any(marker in key_l for marker in ("password", "passwd", "passphrase", "pwd", "pass")):
        return "High" if len(value.strip("\"'")) >= 4 else None
    if any(marker in key_l for marker in ("token", "api_key", "apikey", "access_key", "secret_key", "consumer_key", "app_key", "license_key", "webhook", "sig", "sas")):
        entropy = shannon_entropy(value.strip("\"'"))
        if len(value.strip("\"'")) >= 16 and entropy >= 3.3:
            return "High"
        if len(value.strip("\"'")) >= 8:
            return "Medium"
    if "secret" in key_l and len(value.strip("\"'")) >= 6:
        return "Medium"
    if any(marker in key_l for marker in ("database_url", "jdbc_url", "mongo_url", "redis_url")):
        if "://" in value and ("@" in value or "password" in lowered):
            return "High"
        if "://" in value:
            return "Medium"

    decoded = decode_if_base64(value)
    if decoded:
        return "High"

    configured_matches = [
        keyword for keyword in secret_keywords
        if normalize_keyword(keyword) and normalize_keyword(keyword) in normalized_key
    ]
    if configured_matches:
        clean_value = value.strip("\"'")
        entropy = shannon_entropy(clean_value)
        if len(clean_value) >= 12 and entropy >= 3.0:
            return "High"
        if len(clean_value) >= 6:
            return "Medium"

    return None


def spans_overlap(start: int, end: int, seen_ranges: Sequence[Tuple[int, int]]) -> bool:
    return any(start < existing_end and end > existing_start for existing_start, existing_end in seen_ranges)


def scan_line(
    file_path: Path,
    relative_file_path: str,
    line_number: int,
    line: str,
    owner: str,
    repository_name: str,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
) -> List[Finding]:
    findings: List[Finding] = []
    seen_spans = set()
    seen_ranges: List[Tuple[int, int]] = []

    for rule in HIGH_CONFIDENCE_RULES:
        for match in rule.pattern.finditer(line):
            span = (match.start(), match.end(), rule.name)
            if span in seen_spans:
                continue
            seen_spans.add(span)
            seen_ranges.append((match.start(), match.end()))
            findings.append(
                Finding(
                    file_path=relative_file_path,
                    line_number=line_number,
                    severity=rule.severity,
                    finding_type=rule.name,
                    sensitive_content=mask_sensitive_content(redact_content(match.group(0))),
                    detection_reason=f"Matched known secret pattern: {rule.name}",
                    owner=owner,
                    repository_name=repository_name,
                )
            )

    for match in assignment_re.finditer(line):
        key = match.group("key")
        value = match.group("value").strip()
        severity = classify_assignment_value(key, value, secret_keywords)
        if not severity:
            continue
        seen_ranges.append((match.start(), match.end()))
        content = f"{key}={value}".strip()
        findings.append(
            Finding(
                file_path=relative_file_path,
                line_number=line_number,
                severity=severity,
                finding_type="Sensitive Assignment",
                sensitive_content=mask_sensitive_content(redact_content(content)),
                detection_reason=f"Direct hardcoded sensitive assignment for key '{key}'",
                owner=owner,
                repository_name=repository_name,
            )
        )

    for match in GENERIC_STRING_LITERAL_RE.finditer(line):
        start, end = match.start(), match.end()
        if spans_overlap(start, end, seen_ranges):
            continue
        value = match.group("double") or match.group("single") or match.group("backtick") or ""
        severity = classify_generic_secret_literal(value)
        if not severity:
            continue
        seen_ranges.append((start, end))
        findings.append(
            Finding(
                file_path=relative_file_path,
                line_number=line_number,
                severity=severity,
                finding_type="Generic High-Entropy String",
                sensitive_content=mask_secret(redact_content(unescape_string_literal(value))),
                detection_reason="Suspicious high-entropy string literal detected without a known secret pattern",
                owner=owner,
                repository_name=repository_name,
            )
        )

    return dedupe_findings(findings)


def dedupe_findings(findings: Iterable[Finding]) -> List[Finding]:
    unique = {}
    for finding in findings:
        key = (
            finding.file_path,
            finding.line_number,
            finding.severity,
            finding.finding_type,
            finding.sensitive_content,
        )
        unique[key] = finding
    return list(unique.values())


def is_allowlisted_finding(finding: Finding, allowlist_rules: Sequence[AllowlistRule]) -> bool:
    for rule in allowlist_rules:
        if rule.path_pattern and not matches_any_pattern(finding.file_path, [rule.path_pattern]):
            continue
        if rule.finding_type and finding.finding_type != rule.finding_type:
            continue
        if rule.severity and finding.severity != rule.severity:
            continue
        if rule.line_number is not None and finding.line_number != rule.line_number:
            continue
        if rule.owner and finding.owner != rule.owner:
            continue
        if rule.repository_name and finding.repository_name != rule.repository_name:
            continue
        if rule.content_regex and not rule.content_regex.search(finding.sensitive_content):
            continue
        return True
    return False


def filter_allowlisted_findings(findings: Sequence[Finding], allowlist_rules: Sequence[AllowlistRule]) -> List[Finding]:
    if not allowlist_rules:
        return list(findings)
    return [finding for finding in findings if not is_allowlisted_finding(finding, allowlist_rules)]


def resolve_relative_file_path(path: Path, scan_root: Path) -> str:
    if scan_root.is_file():
        return scan_root.name
    try:
        return path.resolve().relative_to(scan_root.resolve()).as_posix()
    except ValueError:
        return path.name


def sanitize_archive_member_path(member_name: str) -> Optional[Path]:
    normalized_name = member_name.replace("\\", "/")
    member_path = Path(normalized_name)
    if member_path.is_absolute() or member_path.drive:
        return None
    if any(part in {"..", ""} for part in member_path.parts):
        return None
    return member_path


def validate_zip_archive(zip_path: Path, zip_limits: ZipSafetyLimits, archive_depth: int) -> None:
    if archive_depth > zip_limits.max_depth:
        raise RuntimeError(
            f"Zip depth {archive_depth} exceeds the configured limit of {zip_limits.max_depth}."
        )

    with zipfile.ZipFile(zip_path) as archive:
        members = archive.infolist()
        if len(members) > zip_limits.max_members:
            raise RuntimeError(
                f"Zip archive contains {len(members)} entries, which exceeds the configured limit of {zip_limits.max_members}."
            )

        total_uncompressed_bytes = 0
        for member in members:
            sanitized_member = sanitize_archive_member_path(member.filename)
            if sanitized_member is None:
                raise RuntimeError(f"Zip archive contains an unsafe entry path: {member.filename}")
            if member.is_dir():
                continue
            if member.file_size > zip_limits.max_member_size_bytes:
                raise RuntimeError(
                    f"Zip member '{member.filename}' exceeds the configured per-file limit."
                )
            total_uncompressed_bytes += member.file_size
            if total_uncompressed_bytes > zip_limits.max_total_uncompressed_bytes:
                raise RuntimeError(
                    "Zip archive exceeds the configured total uncompressed size limit."
                )


def extract_zip_archive(zip_path: Path, destination: Path, zip_limits: ZipSafetyLimits, archive_depth: int) -> None:
    validate_zip_archive(zip_path, zip_limits, archive_depth)
    destination_root = destination.resolve()

    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            sanitized_member = sanitize_archive_member_path(member.filename)
            if sanitized_member is None:
                raise RuntimeError(f"Zip archive contains an unsafe entry path: {member.filename}")

            destination_path = (destination_root / sanitized_member).resolve()
            if destination_path != destination_root and destination_root not in destination_path.parents:
                raise RuntimeError(f"Zip archive attempted to write outside extraction root: {member.filename}")

            if member.is_dir():
                destination_path.mkdir(parents=True, exist_ok=True)
                continue

            destination_path.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member, "r") as source_handle, destination_path.open("wb") as destination_handle:
                shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)


def scan_file(
    path: Path,
    scan_root: Path,
    owner: str,
    repository_name: str,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
    display_path: Optional[str] = None,
) -> List[Finding]:
    findings: List[Finding] = []
    relative_file_path = display_path or resolve_relative_file_path(path, scan_root)
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line_number, line in enumerate(handle, start=1):
                findings.extend(
                    scan_line(
                        path,
                        relative_file_path,
                        line_number,
                        line.rstrip("\n"),
                        owner,
                        repository_name,
                        assignment_re,
                        secret_keywords,
                    )
                )
    except OSError:
        return []
    return dedupe_findings(findings)


def write_csv(findings: Sequence[Finding], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "owner",
            "repository_name",
            "file_name_with_path",
            "line_number",
            "sensitive_content",
            "severity",
            "finding_type",
            "detection_reason",
        ])
        for finding in sorted(findings, key=lambda item: (item.file_path.lower(), item.line_number, item.finding_type)):
            writer.writerow([
                finding.owner,
                finding.repository_name,
                finding.file_path,
                finding.line_number,
                finding.sensitive_content,
                finding.severity,
                finding.finding_type,
                finding.detection_reason,
            ])


def write_json(findings: Sequence[Finding], output_path: Path, total_targets: int, total_files: int) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    counts = severity_counts(findings)
    payload = {
        "summary": {
            "targets_scanned": total_targets,
            "files_scanned": total_files,
            "total_findings": len(findings),
            "high_severity": counts["high"],
            "medium_severity": counts["medium"],
            "low_severity": counts["low"],
        },
        "findings": [
            finding_to_dict(finding)
            for finding in sorted(findings, key=lambda item: (item.file_path.lower(), item.line_number, item.finding_type))
        ],
    }
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_sarif(findings: Sequence[Finding], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sorted_findings = sorted(findings, key=lambda item: (item.file_path.lower(), item.line_number, item.finding_type))
    rules = []
    seen_rule_ids = set()
    for finding in sorted_findings:
        rule_id = sarif_rule_id(finding.finding_type)
        if rule_id in seen_rule_ids:
            continue
        seen_rule_ids.add(rule_id)
        rules.append(
            {
                "id": rule_id,
                "name": finding.finding_type,
                "shortDescription": {"text": finding.finding_type},
                "fullDescription": {"text": finding.detection_reason},
                "properties": {"defaultSeverity": finding.severity},
            }
        )

    payload = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "secret_scanning.py",
                        "informationUri": "https://example.invalid/secret-scanning",
                        "rules": rules,
                    }
                },
                "results": [
                    {
                        "ruleId": sarif_rule_id(finding.finding_type),
                        "level": sarif_level_for_severity(finding.severity),
                        "message": {"text": finding.detection_reason},
                        "locations": [
                            {
                                "physicalLocation": {
                                    "artifactLocation": {"uri": finding.file_path},
                                    "region": {"startLine": finding.line_number},
                                }
                            }
                        ],
                        "properties": {
                            "severity": finding.severity,
                            "owner": finding.owner,
                            "repository_name": finding.repository_name,
                            "sensitive_content": finding.sensitive_content,
                        },
                    }
                    for finding in sorted_findings
                ],
            }
        ],
    }
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def print_summary(total_targets: int, total_files: int, findings: Sequence[Finding], output_path: Path) -> None:
    counts = severity_counts(findings)
    print("")
    print("Summary")
    print(f"Targets scanned: {total_targets}")
    print(f"Files scanned: {total_files}")
    print(f"Total findings: {len(findings)}")
    print(f"High severity: {counts['high']}")
    print(f"Medium severity: {counts['medium']}")
    print(f"Low severity: {counts['low']}")
    print(f"Report: {output_path}")


def determine_target_metadata(raw_target: str, explicit_owner: str = "", explicit_repository_name: str = "") -> Tuple[str, str]:
    if is_remote_git_url(raw_target):
        provider = detect_provider(raw_target)
        repo_name = explicit_repository_name or derive_repo_name_from_url(raw_target)
        owner = explicit_owner or extract_owner_from_repo_url(raw_target, provider)
        return owner, repo_name

    path = Path(raw_target).expanduser()
    repo_name = explicit_repository_name or sanitize_file_stem(path.stem if path.is_file() else path.name)
    owner = explicit_owner
    return owner, repo_name


def scan_candidate_file(
    file_path: Path,
    display_path: str,
    scan_root: Path,
    owner: str,
    repository_name: str,
    include_hidden: bool,
    max_file_size_kb: int,
    script_path: Path,
    output_path: Path,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
    exclude_patterns: Sequence[str],
    allowlist_rules: Sequence[AllowlistRule],
    zip_limits: ZipSafetyLimits,
    workers: int,
    current_zip_depth: int,
) -> Tuple[List[Finding], int]:
    if file_path.resolve() in {script_path, output_path}:
        return [], 0
    if is_excluded_path(display_path, exclude_patterns):
        return [], 0

    if is_zip_archive(file_path):
        if not should_consider_file(file_path, include_hidden, max_file_size_kb):
            return [], 0
        return scan_zip_archive(
            file_path,
            display_path,
            owner,
            repository_name,
            include_hidden,
            max_file_size_kb,
            script_path,
            output_path,
            assignment_re,
            secret_keywords,
            exclude_patterns,
            allowlist_rules,
            zip_limits,
            workers,
            current_zip_depth + 1,
        )

    if not should_scan_file(file_path, include_hidden, max_file_size_kb):
        return [], 0

    return (
        filter_allowlisted_findings(
            scan_file(
                file_path,
                scan_root,
                owner,
                repository_name,
                assignment_re,
                secret_keywords,
                display_path=display_path,
            ),
            allowlist_rules,
        ),
        1,
    )


def scan_zip_archive(
    zip_path: Path,
    archive_display_path: str,
    owner: str,
    repository_name: str,
    include_hidden: bool,
    max_file_size_kb: int,
    script_path: Path,
    output_path: Path,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
    exclude_patterns: Sequence[str],
    allowlist_rules: Sequence[AllowlistRule],
    zip_limits: ZipSafetyLimits,
    workers: int,
    archive_depth: int,
) -> Tuple[List[Finding], int]:
    temp_root = Path(tempfile.mkdtemp(prefix="sensitive_scan_zip_"))
    extract_root = temp_root / "unzipped"
    extract_root.mkdir(parents=True, exist_ok=True)

    try:
        extract_zip_archive(zip_path, extract_root, zip_limits, archive_depth)
        return scan_path(
            extract_root,
            owner,
            repository_name,
            include_hidden,
            max_file_size_kb,
            script_path,
            output_path,
            assignment_re,
            secret_keywords,
            exclude_patterns,
            allowlist_rules,
            zip_limits,
            workers,
            display_prefix=f"{archive_display_path}!",
            current_zip_depth=archive_depth,
        )
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


def scan_path(
    target: Path,
    owner: str,
    repository_name: str,
    include_hidden: bool,
    max_file_size_kb: int,
    script_path: Path,
    output_path: Path,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
    exclude_patterns: Sequence[str],
    allowlist_rules: Sequence[AllowlistRule],
    zip_limits: ZipSafetyLimits,
    workers: int,
    display_prefix: str = "",
    current_zip_depth: int = 0,
) -> Tuple[List[Finding], int]:
    if not target.exists():
        raise RuntimeError(f"Target path does not exist: {target}")

    if target.is_file():
        if target.resolve() in {script_path, output_path}:
            return [], 0

        if is_zip_archive(target):
            if not should_consider_file(target, include_hidden, max_file_size_kb):
                return [], 0
            archive_display_path = display_prefix.rstrip("!") or target.name
            if is_excluded_path(archive_display_path, exclude_patterns):
                return [], 0
            return scan_zip_archive(
                target,
                archive_display_path,
                owner,
                repository_name,
                include_hidden,
                max_file_size_kb,
                script_path,
                output_path,
                assignment_re,
                secret_keywords,
                exclude_patterns,
                allowlist_rules,
                zip_limits,
                workers,
                current_zip_depth + 1,
            )

        display_path = display_prefix or target.name
        return scan_candidate_file(
            target,
            display_path,
            target,
            owner,
            repository_name,
            include_hidden,
            max_file_size_kb,
            script_path,
            output_path,
            assignment_re,
            secret_keywords,
            exclude_patterns,
            allowlist_rules,
            zip_limits,
            workers,
            current_zip_depth,
        )

    candidates: List[Tuple[Path, str]] = []
    for current_root, dir_names, file_names in os.walk(target):
        current = Path(current_root)
        current_relative = resolve_relative_file_path(current, target) if current != target else ""
        dir_names[:] = [
            directory
            for directory in dir_names
            if directory not in SKIP_DIRS
            and (include_hidden or not directory.startswith("."))
            and not is_excluded_path(
                compose_display_path(display_prefix, f"{current_relative}/{directory}"),
                exclude_patterns,
            )
        ]

        for file_name in file_names:
            file_path = current / file_name
            relative_path = resolve_relative_file_path(file_path, target)
            display_path = compose_display_path(display_prefix, relative_path)
            candidates.append((file_path, display_path))

    findings: List[Finding] = []
    files_scanned = 0
    if not candidates:
        return [], 0

    if workers <= 1 or len(candidates) == 1:
        for file_path, display_path in candidates:
            try:
                file_findings, file_count = scan_candidate_file(
                    file_path,
                    display_path,
                    target,
                    owner,
                    repository_name,
                    include_hidden,
                    max_file_size_kb,
                    script_path,
                    output_path,
                    assignment_re,
                    secret_keywords,
                    exclude_patterns,
                    allowlist_rules,
                    zip_limits,
                    workers,
                    current_zip_depth,
                )
            except RuntimeError as exc:
                print(f"Skipping '{display_path}': {exc}", file=sys.stderr)
                continue
            findings.extend(file_findings)
            files_scanned += file_count
        return dedupe_findings(findings), files_scanned

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {
            executor.submit(
                scan_candidate_file,
                file_path,
                display_path,
                target,
                owner,
                repository_name,
                include_hidden,
                max_file_size_kb,
                script_path,
                output_path,
                assignment_re,
                secret_keywords,
                exclude_patterns,
                allowlist_rules,
                zip_limits,
                workers,
                current_zip_depth,
            ): display_path
            for file_path, display_path in candidates
        }
        for future in concurrent.futures.as_completed(future_map):
            display_path = future_map[future]
            try:
                file_findings, file_count = future.result()
            except RuntimeError as exc:
                print(f"Skipping '{display_path}': {exc}", file=sys.stderr)
                continue
            findings.extend(file_findings)
            files_scanned += file_count

    return dedupe_findings(findings), files_scanned


def scan_single_target(
    raw_target: str,
    output_path: Path,
    include_hidden: bool,
    max_file_size_kb: int,
    script_path: Path,
    assignment_re: re.Pattern[str],
    secret_keywords: Sequence[str],
    exclude_patterns: Sequence[str],
    allowlist_rules: Sequence[AllowlistRule],
    zip_limits: Optional[ZipSafetyLimits] = None,
    workers: int = 1,
    explicit_owner: str = "",
    explicit_repository_name: str = "",
) -> Tuple[List[Finding], int]:
    temp_scan_root: Optional[Path] = None
    owner, repository_name = determine_target_metadata(raw_target, explicit_owner, explicit_repository_name)
    effective_zip_limits = zip_limits or build_zip_safety_limits(2000, 100, 20, 2)

    try:
        if is_remote_git_url(raw_target):
            provider = detect_provider(raw_target)
            provider_label = {
                "github": "GitHub",
                "bitbucket": "Bitbucket",
                "gitlab": "GitLab",
                "azure_devops": "Azure DevOps",
                "generic_git": "Git",
            }.get(provider, "Git")
            print(f"Cloning {provider_label} repository for scanning: {raw_target}")
            target = clone_repository(raw_target)
            temp_scan_root = target.parent
        else:
            target = Path(raw_target).expanduser().resolve()

        if not target.exists():
            raise RuntimeError(f"Target path does not exist: {target}")
        return scan_path(
            target,
            owner,
            repository_name,
            include_hidden,
            max_file_size_kb,
            script_path,
            output_path,
            assignment_re,
            secret_keywords,
            exclude_patterns,
            allowlist_rules,
            effective_zip_limits,
            workers,
        )
    finally:
        if temp_scan_root and temp_scan_root.exists():
            shutil.rmtree(temp_scan_root, ignore_errors=True)


def build_output_path(output_arg: Optional[str], report_stem: str, output_format: str) -> Path:
    if output_arg:
        return Path(output_arg).resolve()
    suffix = {
        "json": ".json",
        "sarif": ".sarif",
        "csv": ".csv",
    }.get(output_format, ".csv")
    return (Path.cwd() / f"{report_stem}{suffix}").resolve()


def main() -> int:
    args = parse_args()
    script_path = Path(__file__).resolve()
    secret_keywords = tuple(DEFAULT_SECRET_KEYWORDS)
    assignment_re = build_assignment_regex(secret_keywords)

    raw_target = args.target
    targets_csv = args.targets_csv
    total_targets = 0
    exclude_patterns = tuple(args.exclude or [])
    try:
        allowlist_rules = load_allowlist_rules(args.allowlist_file)
        zip_limits = build_zip_safety_limits(
            args.max_zip_members,
            args.max_zip_uncompressed_mb,
            args.max_zip_member_size_mb,
            args.max_zip_depth,
        )
        workers = resolve_worker_count(args.workers)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    if not raw_target and not targets_csv:
        if args.non_interactive:
            print("Target path or Git repository URL is required in non-interactive mode.", file=sys.stderr)
            return 1
        raw_target = prompt_for_target()

    if raw_target and raw_target.lower().endswith(".csv") and not targets_csv:
        targets_csv = raw_target
        raw_target = None

    all_findings: List[Finding] = []
    total_files_scanned = 0

    if targets_csv:
        csv_path = Path(targets_csv).expanduser().resolve()
        if not csv_path.exists():
            print(f"Targets CSV does not exist: {csv_path}", file=sys.stderr)
            return 1

        try:
            targets = read_targets_from_csv(csv_path)
        except RuntimeError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        total_targets = len(targets)

        report_stem = sanitize_file_stem(csv_path.stem)
        output_path = build_output_path(args.output, f"{report_stem}_report", args.format)

        for entry in targets:
            try:
                findings, file_count = scan_single_target(
                    entry["target"],
                    output_path,
                    args.include_hidden,
                    args.max_file_size_kb,
                    script_path,
                    assignment_re,
                    secret_keywords,
                    exclude_patterns,
                    allowlist_rules,
                    zip_limits,
                    workers,
                    explicit_owner=entry.get("owner", ""),
                    explicit_repository_name=entry.get("repository_name", ""),
                )
                all_findings.extend(findings)
                total_files_scanned += file_count
            except RuntimeError as exc:
                print(f"Skipping target '{entry['target']}': {exc}", file=sys.stderr)
    else:
        owner, repository_name = determine_target_metadata(raw_target)
        report_stem = sanitize_file_stem(repository_name)
        output_path = build_output_path(args.output, report_stem, args.format)
        total_targets = 1
        try:
            findings, total_files_scanned = scan_single_target(
                raw_target,
                output_path,
                args.include_hidden,
                args.max_file_size_kb,
                script_path,
                assignment_re,
                secret_keywords,
                exclude_patterns,
                allowlist_rules,
                zip_limits,
                workers,
                explicit_owner=owner,
                explicit_repository_name=repository_name,
            )
            all_findings.extend(findings)
        except RuntimeError as exc:
            print(str(exc), file=sys.stderr)
            return 1

    all_findings = dedupe_findings(all_findings)
    if args.format == "json":
        write_json(all_findings, output_path, total_targets, total_files_scanned)
    elif args.format == "sarif":
        write_sarif(all_findings, output_path)
    else:
        write_csv(all_findings, output_path)

    print_summary(
        total_targets=total_targets,
        total_files=total_files_scanned,
        findings=all_findings,
        output_path=output_path,
    )

    return 2 if should_fail_scan(all_findings, args.fail_on) else 0


if __name__ == "__main__":
    raise SystemExit(main())
