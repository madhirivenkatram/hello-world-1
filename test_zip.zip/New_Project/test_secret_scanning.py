import json
import os
import tempfile
import unittest
from unittest import mock
from pathlib import Path
import zipfile

import secret_scanning


class SecretScanningTests(unittest.TestCase):
    def setUp(self) -> None:
        self.secret_keywords = tuple(secret_scanning.DEFAULT_SECRET_KEYWORDS)
        self.assignment_re = secret_scanning.build_assignment_regex(self.secret_keywords)

    def test_password_assignment_is_high_severity(self) -> None:
        severity = secret_scanning.classify_assignment_value(
            "db_password",
            '"super-secret-value"',
            self.secret_keywords,
        )
        self.assertEqual(severity, "High")

    def test_username_assignment_is_not_flagged(self) -> None:
        severity = secret_scanning.classify_assignment_value(
            "username",
            '"admin@example.com"',
            self.secret_keywords,
        )
        self.assertIsNone(severity)

    def test_client_id_assignment_is_not_flagged(self) -> None:
        severity = secret_scanning.classify_assignment_value(
            "client_id",
            '"1234567890abcdef"',
            self.secret_keywords,
        )
        self.assertIsNone(severity)

    def test_known_token_pattern_is_detected(self) -> None:
        findings = secret_scanning.scan_line(
            file_path=Path("app.py"),
            relative_file_path="app.py",
            line_number=10,
            line='token = "ghp_abcdefghijklmnopqrstuvwxyz123456"',
            owner="example-owner",
            repository_name="example-repo",
            assignment_re=self.assignment_re,
            secret_keywords=self.secret_keywords,
        )
        self.assertTrue(any(f.finding_type == "GitHub Token" for f in findings))

    def test_generic_high_entropy_string_literal_is_detected(self) -> None:
        findings = secret_scanning.scan_line(
            file_path=Path("app.js"),
            relative_file_path="app.js",
            line_number=4,
            line='const data = "A1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6";',
            owner="example-owner",
            repository_name="example-repo",
            assignment_re=self.assignment_re,
            secret_keywords=self.secret_keywords,
        )
        self.assertTrue(any(f.finding_type == "Generic High-Entropy String" for f in findings))

    def test_generic_url_string_is_not_detected(self) -> None:
        findings = secret_scanning.scan_line(
            file_path=Path("app.js"),
            relative_file_path="app.js",
            line_number=5,
            line='const endpoint = "https://example.com/api/v1/resource";',
            owner="example-owner",
            repository_name="example-repo",
            assignment_re=self.assignment_re,
            secret_keywords=self.secret_keywords,
        )
        self.assertEqual(findings, [])

    def test_assignment_finding_is_not_duplicated_by_generic_entropy_detection(self) -> None:
        findings = secret_scanning.scan_line(
            file_path=Path("settings.env"),
            relative_file_path="settings.env",
            line_number=1,
            line='db_password="abcdefgh12345678"',
            owner="example-owner",
            repository_name="example-repo",
            assignment_re=self.assignment_re,
            secret_keywords=self.secret_keywords,
        )
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].finding_type, "Sensitive Assignment")

    def test_single_file_scan_reports_filename(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "settings.env"
            file_path.write_text('db_password="supersecret"\n', encoding="utf-8")

            findings = secret_scanning.scan_file(
                path=file_path,
                scan_root=file_path,
                owner="",
                repository_name="settings",
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
            )

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, "settings.env")

    def test_local_dotenv_file_is_scanned_without_include_hidden(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            file_path = tmp_path / ".env"
            output_path = tmp_path / "report.csv"
            file_path.write_text('db_password="supersecret"\n', encoding="utf-8")

            findings, file_count = secret_scanning.scan_single_target(
                str(file_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, ".env")

    def test_git_auth_env_uses_extraheader(self) -> None:
        env = secret_scanning.build_git_auth_env("sample-token", "github")
        self.assertEqual(env["GIT_CONFIG_COUNT"], "1")
        self.assertEqual(env["GIT_CONFIG_KEY_0"], "http.extraheader")
        self.assertTrue(env["GIT_CONFIG_VALUE_0"].startswith("AUTHORIZATION: basic "))

    def test_zip_target_is_scanned(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_path = tmp_path / "bundle.zip"
            output_path = tmp_path / "report.csv"
            source_file = tmp_path / "settings.env"
            source_file.write_text('db_password="supersecret"\n', encoding="utf-8")

            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.write(source_file, arcname="settings.env")

            findings, file_count = secret_scanning.scan_single_target(
                str(zip_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, "bundle.zip!settings.env")

    def test_zip_target_scans_dotenv_file_without_include_hidden(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_path = tmp_path / "bundle.zip"
            output_path = tmp_path / "report.csv"
            source_file = tmp_path / ".env"
            source_file.write_text('db_password="supersecret"\n', encoding="utf-8")

            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.write(source_file, arcname=".env")

            findings, file_count = secret_scanning.scan_single_target(
                str(zip_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, "bundle.zip!.env")
        self.assertEqual(findings[0].finding_type, "Sensitive Assignment")

    def test_large_zip_container_is_scanned_when_inner_text_file_is_small(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_path = tmp_path / "bundle.zip"
            output_path = tmp_path / "report.csv"
            large_binary = tmp_path / "installer.exe"
            secret_file = tmp_path / "ram.txt"
            large_binary.write_bytes(b"\x00" * (2 * 1024 * 1024))
            secret_file.write_text("password: 33456@123&8*\n", encoding="utf-8")

            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.write(large_binary, arcname="installer.exe")
                archive.write(secret_file, arcname="ram.txt")

            findings, file_count = secret_scanning.scan_single_target(
                str(zip_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, "bundle.zip!ram.txt")
        self.assertEqual(findings[0].finding_type, "Sensitive Assignment")

    def test_zip_inside_directory_is_scanned(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            project_dir = tmp_path / "project"
            project_dir.mkdir()
            zip_path = project_dir / "artifacts.zip"
            output_path = tmp_path / "report.csv"
            source_file = tmp_path / "app.env"
            source_file.write_text('api_token="abcdefgh12345678"\n', encoding="utf-8")

            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.write(source_file, arcname="config/app.env")

            findings, file_count = secret_scanning.scan_single_target(
                str(project_dir),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].file_path, "artifacts.zip!config/app.env")

    def test_exclude_pattern_skips_matching_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            file_path = tmp_path / "settings.env"
            output_path = tmp_path / "report.csv"
            file_path.write_text('db_password="supersecret"\n', encoding="utf-8")

            findings, file_count = secret_scanning.scan_single_target(
                str(tmp_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=("*.env",),
                allowlist_rules=(),
            )

        self.assertEqual(file_count, 0)
        self.assertEqual(findings, [])

    def test_allowlist_rule_suppresses_matching_finding(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            file_path = tmp_path / "settings.env"
            output_path = tmp_path / "report.csv"
            allowlist_path = tmp_path / "allowlist.json"
            file_path.write_text('db_password="supersecret"\n', encoding="utf-8")
            allowlist_path.write_text(
                json.dumps(
                    {
                        "rules": [
                            {
                                "path": "settings.env",
                                "finding_type": "Sensitive Assignment",
                                "line_number": 1,
                            }
                        ]
                    }
                ),
                encoding="utf-8",
            )

            findings, file_count = secret_scanning.scan_single_target(
                str(file_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=secret_scanning.load_allowlist_rules(str(allowlist_path)),
            )

        self.assertEqual(file_count, 1)
        self.assertEqual(findings, [])

    def test_write_json_output_contains_summary_and_findings(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            output_path = Path(tmp_dir) / "report.json"
            findings = [
                secret_scanning.Finding(
                    file_path="settings.env",
                    line_number=3,
                    severity="High",
                    finding_type="Sensitive Assignment",
                    sensitive_content="db_password=s*********t",
                    detection_reason="Direct hardcoded sensitive assignment for key 'db_password'",
                    owner="",
                    repository_name="demo",
                )
            ]

            secret_scanning.write_json(findings, output_path, total_targets=1, total_files=4)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        self.assertEqual(payload["summary"]["targets_scanned"], 1)
        self.assertEqual(payload["summary"]["files_scanned"], 4)
        self.assertEqual(payload["summary"]["total_findings"], 1)
        self.assertEqual(payload["findings"][0]["file_name_with_path"], "settings.env")

    def test_write_sarif_output_contains_results(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            output_path = Path(tmp_dir) / "report.sarif"
            findings = [
                secret_scanning.Finding(
                    file_path="settings.env",
                    line_number=3,
                    severity="High",
                    finding_type="Sensitive Assignment",
                    sensitive_content="db_password=s*********t",
                    detection_reason="Direct hardcoded sensitive assignment for key 'db_password'",
                    owner="",
                    repository_name="demo",
                )
            ]

            secret_scanning.write_sarif(findings, output_path)
            payload = json.loads(output_path.read_text(encoding="utf-8"))

        self.assertEqual(payload["version"], "2.1.0")
        self.assertEqual(payload["runs"][0]["results"][0]["ruleId"], "Sensitive_Assignment")
        self.assertEqual(
            payload["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]["uri"],
            "settings.env",
        )

    def test_zip_safety_limit_rejects_large_member_count(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            zip_path = tmp_path / "bundle.zip"
            output_path = tmp_path / "report.csv"

            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.writestr("one.txt", 'db_password="supersecret"\n')
                archive.writestr("two.txt", 'api_token="abcdefgh12345678"\n')

            with self.assertRaises(RuntimeError):
                secret_scanning.scan_single_target(
                    str(zip_path),
                    output_path=output_path,
                    include_hidden=False,
                    max_file_size_kb=1024,
                    script_path=Path(secret_scanning.__file__).resolve(),
                    assignment_re=self.assignment_re,
                    secret_keywords=self.secret_keywords,
                    exclude_patterns=(),
                    allowlist_rules=(),
                    zip_limits=secret_scanning.build_zip_safety_limits(1, 100, 20, 2),
                )

    def test_nested_zip_depth_limit_skips_inner_archive(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            project_dir = tmp_path / "project"
            project_dir.mkdir()
            inner_zip = tmp_path / "inner.zip"
            outer_zip = project_dir / "outer.zip"
            output_path = tmp_path / "report.csv"

            with zipfile.ZipFile(inner_zip, "w") as archive:
                archive.writestr("settings.env", 'db_password="supersecret"\n')
            with zipfile.ZipFile(outer_zip, "w") as archive:
                archive.write(inner_zip, arcname="nested/inner.zip")

            findings, file_count = secret_scanning.scan_single_target(
                str(project_dir),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
                zip_limits=secret_scanning.build_zip_safety_limits(2000, 100, 20, 1),
            )

        self.assertEqual(file_count, 0)
        self.assertEqual(findings, [])

    def test_parallel_scan_matches_single_worker_results(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            output_path = tmp_path / "report.csv"
            (tmp_path / "a.env").write_text('db_password="supersecret"\n', encoding="utf-8")
            (tmp_path / "b.txt").write_text("ghp_abcdefghijklmnopqrstuvwxyz123456\n", encoding="utf-8")
            (tmp_path / "c.js").write_text('const data = "A1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6";\n', encoding="utf-8")

            sequential_findings, sequential_count = secret_scanning.scan_single_target(
                str(tmp_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
                workers=1,
            )
            parallel_findings, parallel_count = secret_scanning.scan_single_target(
                str(tmp_path),
                output_path=output_path,
                include_hidden=False,
                max_file_size_kb=1024,
                script_path=Path(secret_scanning.__file__).resolve(),
                assignment_re=self.assignment_re,
                secret_keywords=self.secret_keywords,
                exclude_patterns=(),
                allowlist_rules=(),
                workers=4,
            )

        sequential_keys = sorted((f.file_path, f.line_number, f.finding_type, f.severity) for f in sequential_findings)
        parallel_keys = sorted((f.file_path, f.line_number, f.finding_type, f.severity) for f in parallel_findings)
        self.assertEqual(sequential_count, parallel_count)
        self.assertEqual(sequential_keys, parallel_keys)

    def test_prompt_for_target_returns_local_path_choice(self) -> None:
        with mock.patch("builtins.input", side_effect=["2", "C:\\repo"]):
            selected = secret_scanning.prompt_for_target()
        self.assertEqual(selected, "C:\\repo")

    def test_main_returns_nonzero_when_fail_on_threshold_is_met(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            file_path = tmp_path / "settings.env"
            file_path.write_text('db_password="supersecret"\n', encoding="utf-8")
            original_cwd = os.getcwd()
            try:
                os.chdir(tmp_path)
                with mock.patch(
                    "sys.argv",
                    ["secret_scanning.py", str(file_path), "--fail-on", "high"],
                ):
                    exit_code = secret_scanning.main()
            finally:
                os.chdir(original_cwd)

        self.assertEqual(exit_code, 2)


if __name__ == "__main__":
    unittest.main()
