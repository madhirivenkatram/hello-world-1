# Secret Scanning Guide

## What This Script Does

`secret_scanning.py` scans a local file, a local folder, a `.zip` archive, a remote Git repository, or a CSV list of targets for possible hardcoded secrets.

It exports the results to a CSV report with:

- `owner`
- `repository_name`
- `file_name_with_path`
- `line_number`
- `sensitive_content`
- `severity`
- `finding_type`
- `detection_reason`

The script masks detected values in the output so the report does not expose the full secret again.
It can write reports as CSV, JSON, or SARIF.

## Requirements

- Python 3
- Git installed if you want to scan remote repositories

## Basic Usage

Scan the current directory:

```bash
python secret_scanning.py .
```

Scan a specific folder:

```bash
python secret_scanning.py C:\path\to\project
```

Scan a single file:

```bash
python secret_scanning.py C:\path\to\settings.env
```

Scan a zip archive:

```bash
python secret_scanning.py C:\path\to\bundle.zip
```

Scan a remote Git repository:

```bash
python secret_scanning.py https://github.com/example-org/example-repo.git
```

If the repo is private, the script will prompt for a personal access token.

## Output File

By default, the script writes a CSV in the current folder.

Examples:

- Local folder `my-app` becomes `my-app.csv`
- CSV input `targets.csv` becomes `targets_report.csv`

You can also choose the output path yourself:

```bash
python secret_scanning.py C:\path\to\project --output C:\reports\scan_results.csv
```

Generate JSON instead of CSV:

```bash
python secret_scanning.py C:\path\to\project --format json --output C:\reports\scan_results.json
```

Generate SARIF for CI/security platforms:

```bash
python secret_scanning.py C:\path\to\project --format sarif --output C:\reports\scan_results.sarif
```

## Useful Options

Include hidden files and folders:

```bash
python secret_scanning.py C:\path\to\project --include-hidden
```

Change max file size limit:

```bash
python secret_scanning.py C:\path\to\project --max-file-size-kb 2048
```

Scan multiple targets from a CSV:

```bash
python secret_scanning.py --targets-csv C:\path\to\targets.csv
```

Run without arguments to choose the source interactively:

```bash
python secret_scanning.py
```

The script will ask whether you want to scan:

- a Git repository URL
- a local folder, file, or zip path
- a CSV file with multiple targets

Exclude paths with glob patterns:

```bash
python secret_scanning.py C:\path\to\project --exclude "*.env.example" --exclude "tests/*"
```

Fail the command in CI when findings meet a severity threshold:

```bash
python secret_scanning.py C:\path\to\project --fail-on medium
```

Use an allowlist file to suppress approved findings:

```bash
python secret_scanning.py C:\path\to\project --allowlist-file C:\path\to\allowlist.json
```

Use parallel scanning workers for larger repositories:

```bash
python secret_scanning.py C:\path\to\project --workers 8
```

Apply zip safety limits:

```bash
python secret_scanning.py C:\path\to\archives --max-zip-members 1000 --max-zip-uncompressed-mb 50 --max-zip-member-size-mb 10 --max-zip-depth 2
```

## Targets CSV Format

The CSV must include one of these columns:

- `target`
- `github_url`
- `local_path`

Optional columns:

- `owner`
- `repository_name`

Example:

```csv
target,owner,repository_name
https://github.com/example-org/api-service.git,example-org,api-service
C:\repos\internal-app,internal-team,internal-app
```

## Example Commands

Run against the current project and save the report explicitly:

```bash
python secret_scanning.py . --output .\secret_scan_report.csv
```

Run against the current project, write JSON output, and fail CI on high-severity findings:

```bash
python secret_scanning.py . --format json --fail-on high --output .\secret_scan_report.json
```

Run against the current project, produce SARIF, and use 8 worker threads:

```bash
python secret_scanning.py . --format sarif --workers 8 --output .\secret_scan_report.sarif
```

Run tests:

```bash
python -m unittest -v
```

Check syntax:

```bash
python -m py_compile secret_scanning.py test_secret_scanning.py
```

## What It Detects

The script looks for:

- Known secret patterns like AWS keys, GitHub tokens, Slack webhooks, JWTs, and private key headers
- Hardcoded assignments such as `password=...`, `token=...`, `client_secret=...`, and connection strings
- Suspicious high-entropy string literals even when they are not assigned to obvious names like `password` or `token`

It also tries to reduce noise by skipping:

- Common build and dependency folders
- Large files
- Likely binary files
- Placeholder values like `changeme` and `example`
- Variable references like environment variables or template expressions
- Common non-secret literals like normal URLs and some identifier-style values

Common secret-bearing dotfiles such as `.env`, `.env.production`, `.npmrc`, and `.netrc` are still scanned by default, including when they are found inside zip archives.

## Zip Support

- If you target a `.zip` file directly, the script extracts it to a temporary folder and scans the extracted contents.
- If a folder being scanned contains `.zip` files, those archives are also extracted and scanned automatically.
- Findings from archives are reported in the CSV using a path like `bundle.zip!config/app.env`.
- Zip scanning is bounded by safety limits for member count, total uncompressed size, per-member size, and nesting depth.
- Archives with unsafe paths or size/depth violations are rejected or skipped to reduce decompression-abuse risk.
- The normal `--max-file-size-kb` limit applies to extracted files, not to the outer zip container itself.

## SARIF Output

- Use `--format sarif` to generate SARIF 2.1.0 output.
- This format is suitable for enterprise CI/CD and security tooling that supports SARIF ingestion.
- Findings include file location, line number, rule ID, severity mapping, and masked content in result properties.

## Parallel Scanning

- Use `--workers <n>` to scan directory contents with multiple threads.
- `--workers 0` uses an automatic worker count.
- Parallel scanning helps with larger repositories while preserving the same findings as single-threaded scans.

## Allowlist File Format

The allowlist file must be JSON. It can be either:

- a top-level array of rules
- or an object with a `rules` array

Each rule can include any of these fields:

- `path`
- `finding_type`
- `severity`
- `line_number`
- `content_regex`
- `owner`
- `repository_name`

Example:

```json
{
  "rules": [
    {
      "path": "tests/fixtures/*.env",
      "finding_type": "Sensitive Assignment"
    },
    {
      "path": "demo.zip!config/app.env",
      "line_number": 4,
      "severity": "High"
    }
  ]
}
```

Rules are matched as an allowlist, so if all fields in a rule match a finding, that finding is suppressed.

## Notes

- This is a heuristic scanner, so it can still produce false positives and false negatives.
- Multi-line secrets may be harder to detect than single-line values.
- For remote repositories and zip archives, the script uses temporary folders and removes them after scanning.
- `--fail-on low|medium|high` returns exit code `2` when findings meet or exceed the selected threshold.
- `--non-interactive` disables prompting and requires you to pass a target explicitly.
- Unsafe zip archives can be skipped or rejected when they exceed configured safety limits.
